# Anime Streaming Platform

Browse and search anime with an easy-to-use interface.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Run the server:
```bash
npm start
```

3. Open your browser and go to:
```
http://localhost:6000
```

## Features

- Search for any anime
- Browse trending/popular anime
- Clean and responsive interface
- Direct links to watch anime

## Reference Site

Data is fetched from hianime.to
