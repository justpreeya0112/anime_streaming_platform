const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const resultsDiv = document.getElementById('results');
const loadingDiv = document.getElementById('loading');
const errorDiv = document.getElementById('error');
const navbar = document.querySelector('.navbar');
const hero = document.getElementById('hero');
const heroTitle = document.getElementById('heroTitle');
const heroDesc = document.getElementById('heroDesc');
const heroPlay = document.getElementById('heroPlay');
const heroInfo = document.getElementById('heroInfo');

let heroAnime = null;
let allSections = {};

// Navbar scroll effect
window.addEventListener('scroll', () => {
    if (window.scrollY > 100) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Initialize navigation
document.addEventListener('DOMContentLoaded', () => {
    setupNavigation();
    setupIcons();
});

// Load home page on page load
loadHome();

// Search on button click
searchBtn.addEventListener('click', performSearch);

// Search on Enter key
searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        performSearch();
    }
});

// Setup navigation tabs
function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-menu li');
    
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            // Remove active class from all items
            navItems.forEach(i => i.classList.remove('active'));
            // Add active class to clicked item
            item.classList.add('active');
            
            const text = item.textContent.toLowerCase();
            
            switch(text) {
                case 'home':
                    loadHome();
                    break;
                case 'trending':
                    loadSection('trending', 'Trending Anime', 'fa-fire');
                    break;
                case 'popular':
                    loadSection('popular', 'Popular Anime', 'fa-chart-line');
                    break;
                case 'new':
                    loadSection('new', 'Recently Released Episodes', 'fa-clock');
                    break;
                case 'movies':
                    loadSection('movies', 'Anime Movies', 'fa-film');
                    break;
            }
        });
    });
}

// Setup notification and profile icons
function setupIcons() {
    const notificationIcon = document.querySelector('.notification-icon');
    const profileIcon = document.querySelector('.profile-icon');
    const logo = document.querySelector('.logo');
    
    if (notificationIcon) {
        notificationIcon.addEventListener('click', () => {
            showNotification('You have 3 new episodes available!');
        });
    }
    
    if (profileIcon) {
        profileIcon.addEventListener('click', () => {
            showNotification('Profile settings coming soon!');
        });
    }
    
    if (logo) {
        logo.addEventListener('click', () => {
            const homeTab = document.querySelector('.nav-menu li');
            if (homeTab) {
                homeTab.click();
            }
        });
    }
}

// Show notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification-popup';
    notification.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Load specific section
async function loadSection(endpoint, title, icon) {
    showLoading();
    hideError();
    hero.style.display = 'none';
    
    try {
        const response = await fetch(`/api/${endpoint}`);
        const data = await response.json();
        
        hideLoading();
        
        if (data.success && data.results) {
            resultsDiv.innerHTML = '';
            displayExpandedRow(data.results, title, icon);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            showError('Failed to load content');
        }
    } catch (error) {
        hideLoading();
        showError('Network error. Please try again.');
    }
}

async function performSearch() {
    const query = searchInput.value.trim();
    
    if (!query) {
        loadHome();
        return;
    }
    
    showLoading();
    hideError();
    
    try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const data = await response.json();
        
        hideLoading();
        
        if (data.success) {
            displaySingleRow(data.results, 'Search Results');
        } else {
            showError('Failed to search anime');
        }
    } catch (error) {
        hideLoading();
        showError('Network error. Please try again.');
    }
}

async function loadHome() {
    showLoading();
    hideError();
    hero.style.display = 'flex';
    
    try {
        const response = await fetch('/api/home');
        const data = await response.json();
        
        hideLoading();
        
        if (data.success) {
            const sections = data.sections;
            allSections = sections;
            
            // Set hero banner from trending
            if (sections.trending && sections.trending.length > 0) {
                heroAnime = sections.trending[0];
                setupHero(heroAnime);
            }
            
            // Display all sections
            resultsDiv.innerHTML = '';
            
            if (sections.trending && sections.trending.length > 0) {
                displayRow(sections.trending, 'Trending Now', 'fa-fire', 'trending');
            }
            
            if (sections.latest && sections.latest.length > 0) {
                displayRow(sections.latest, 'Latest Episodes', 'fa-clock', 'latest');
            }
            
            if (sections.popular && sections.popular.length > 0) {
                displayRow(sections.popular, 'Popular This Week', 'fa-chart-line', 'popular');
            }
            
            if (sections.upcoming && sections.upcoming.length > 0) {
                displayRow(sections.upcoming, 'Coming Soon', 'fa-calendar-alt', 'upcoming');
            }
            
            if (sections.newReleases && sections.newReleases.length > 0) {
                displayRow(sections.newReleases, 'New Releases', 'fa-star', 'newReleases');
            }
        } else {
            showError('Failed to load anime');
        }
    } catch (error) {
        hideLoading();
        showError('Network error. Please try again.');
    }
}

function setupHero(anime) {
    heroTitle.textContent = anime.title;
    heroDesc.textContent = 'Experience the most thrilling anime adventures. Watch now in stunning HD quality.';
    document.getElementById('heroEpisodes').textContent = anime.episodes || '24 Episodes';
    hero.style.backgroundImage = `url('${anime.image}')`;
    
    heroPlay.onclick = () => window.open(anime.link, '_blank');
    heroInfo.onclick = () => window.open(anime.link, '_blank');
}

function displayRow(results, title, icon = 'fa-fire', sectionKey = '') {
    if (results.length === 0) return;
    
    const row = document.createElement('div');
    row.className = 'anime-row';
    
    const rowHeader = document.createElement('div');
    rowHeader.className = 'row-header';
    
    const rowTitle = document.createElement('h2');
    rowTitle.className = 'row-title';
    rowTitle.innerHTML = `<i class="fas ${icon}"></i> ${title}`;
    
    const viewAll = document.createElement('span');
    viewAll.className = 'view-all';
    viewAll.textContent = 'View All ›';
    viewAll.onclick = () => {
        hero.style.display = 'none';
        resultsDiv.innerHTML = '';
        displayExpandedRow(results, title, icon);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    
    rowHeader.appendChild(rowTitle);
    rowHeader.appendChild(viewAll);
    
    const rowPosters = document.createElement('div');
    rowPosters.className = 'row-posters';
    
    results.forEach((anime, index) => {
        const card = document.createElement('div');
        card.className = 'anime-card';
        card.onclick = () => window.open(anime.link, '_blank');
        
        const rating = (8.5 + Math.random() * 1.5).toFixed(1);
        
        card.innerHTML = `
            <img src="${anime.image}" 
                 alt="${anime.title}"
                 onerror="this.src='https://via.placeholder.com/240x340?text=No+Image'">
            ${index < 3 ? '<div class="anime-badge">TOP</div>' : ''}
            <div class="anime-info">
                <div class="anime-title">${anime.title}</div>
                <div class="anime-meta">
                    <span class="anime-episodes">${anime.episodes}</span>
                    <span class="anime-rating"><i class="fas fa-star"></i> ${rating}</span>
                </div>
            </div>
        `;
        
        rowPosters.appendChild(card);
    });
    
    row.appendChild(rowHeader);
    row.appendChild(rowPosters);
    resultsDiv.appendChild(row);
}

function displayExpandedRow(results, title, icon) {
    const row = document.createElement('div');
    row.className = 'anime-row expanded';
    
    const rowHeader = document.createElement('div');
    rowHeader.className = 'row-header';
    
    const rowTitle = document.createElement('h2');
    rowTitle.className = 'row-title';
    rowTitle.innerHTML = `<i class="fas ${icon}"></i> ${title}`;
    
    const backBtn = document.createElement('span');
    backBtn.className = 'view-all';
    backBtn.innerHTML = '<i class="fas fa-arrow-left"></i> Back to Home';
    backBtn.onclick = () => loadHome();
    
    rowHeader.appendChild(rowTitle);
    rowHeader.appendChild(backBtn);
    
    const grid = document.createElement('div');
    grid.className = 'anime-grid';
    
    results.forEach((anime, index) => {
        const card = document.createElement('div');
        card.className = 'anime-card';
        card.onclick = () => window.open(anime.link, '_blank');
        
        const rating = (8.5 + Math.random() * 1.5).toFixed(1);
        
        card.innerHTML = `
            <img src="${anime.image}" 
                 alt="${anime.title}"
                 onerror="this.src='https://via.placeholder.com/240x340?text=No+Image'">
            ${index < 3 ? '<div class="anime-badge">TOP</div>' : ''}
            <div class="anime-info">
                <div class="anime-title">${anime.title}</div>
                <div class="anime-meta">
                    <span class="anime-episodes">${anime.episodes}</span>
                    <span class="anime-rating"><i class="fas fa-star"></i> ${rating}</span>
                </div>
            </div>
        `;
        
        grid.appendChild(card);
    });
    
    row.appendChild(rowHeader);
    row.appendChild(grid);
    resultsDiv.appendChild(row);
}

function displaySingleRow(results, title) {
    resultsDiv.innerHTML = '';
    
    if (results.length === 0) {
        resultsDiv.innerHTML = '<p style="color: white; text-align: center; padding: 50px;">No anime found</p>';
        return;
    }
    
    displayRow(results, title, 'fa-search');
}

function showLoading() {
    loadingDiv.style.display = 'block';
}

function hideLoading() {
    loadingDiv.style.display = 'none';
}

function showError(message) {
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

function hideError() {
    errorDiv.style.display = 'none';
}
