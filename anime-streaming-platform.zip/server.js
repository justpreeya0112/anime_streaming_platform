const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Base URL for anime site
const BASE_URL = 'https://hianimez.is';

// Helper function to parse anime items
function parseAnimeItems($, selector, limit = null) {
  const results = [];
  const items = limit ? $(selector).slice(0, limit) : $(selector);
  
  items.each((i, elem) => {
    const title = $(elem).find('.film-name a, .dynamic-name').text().trim();
    const link = $(elem).find('.film-poster a, a').attr('href');
    const image = $(elem).find('.film-poster img, img').attr('data-src') || 
                  $(elem).find('.film-poster img, img').attr('src');
    const episodes = $(elem).find('.tick-eps, .tick-item').text().trim();
    
    if (title && link) {
      results.push({
        title,
        link: link.startsWith('http') ? link : `${BASE_URL}${link}`,
        image: image || 'https://via.placeholder.com/200x300?text=No+Image',
        episodes: episodes || 'N/A'
      });
    }
  });
  
  return results;
}

// Get home page with multiple sections
app.get('/api/home', async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/home`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    const $ = cheerio.load(response.data);
    
    const sections = {
      trending: parseAnimeItems($, '#trending-home .flw-item', 30),
      latest: parseAnimeItems($, '#latest-update .flw-item', 30),
      popular: parseAnimeItems($, '#popular-home .flw-item', 30),
      upcoming: parseAnimeItems($, '#upcoming-home .flw-item', 30),
      newReleases: parseAnimeItems($, '.flw-item', 30).slice(0, 30)
    };
    
    res.json({ success: true, sections });
  } catch (error) {
    console.error('Home error:', error.message);
    res.status(500).json({ success: false, error: 'Failed to fetch home data' });
  }
});

// Search anime
app.get('/api/search', async (req, res) => {
  try {
    const query = req.query.q || '';
    const response = await axios.get(`${BASE_URL}/search?keyword=${encodeURIComponent(query)}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    const $ = cheerio.load(response.data);
    
    const results = parseAnimeItems($, '.flw-item');
    
    res.json({ success: true, results });
  } catch (error) {
    console.error('Search error:', error.message);
    res.status(500).json({ success: false, error: 'Failed to search anime' });
  }
});

// Get trending anime
app.get('/api/trending', async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/home`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    const $ = cheerio.load(response.data);
    
    let results = parseAnimeItems($, '#trending-home .flw-item', 50);
    
    // Fallback if no results
    if (results.length === 0) {
      results = parseAnimeItems($, '.flw-item', 50);
    }
    
    res.json({ success: true, results });
  } catch (error) {
    console.error('Trending error:', error.message);
    res.status(500).json({ success: false, error: 'Failed to fetch trending anime' });
  }
});

// Get popular anime
app.get('/api/popular', async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/home`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    const $ = cheerio.load(response.data);
    
    let results = parseAnimeItems($, '#popular-home .flw-item', 50);
    
    // Fallback if no results
    if (results.length === 0) {
      results = parseAnimeItems($, '.flw-item', 50);
    }
    
    res.json({ success: true, results });
  } catch (error) {
    console.error('Popular error:', error.message);
    res.status(500).json({ success: false, error: 'Failed to fetch popular anime' });
  }
});

// Get new/latest episodes
app.get('/api/new', async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/home`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    const $ = cheerio.load(response.data);
    
    let results = parseAnimeItems($, '#latest-update .flw-item', 50);
    
    // Fallback if no results
    if (results.length === 0) {
      results = parseAnimeItems($, '.flw-item', 50);
    }
    
    res.json({ success: true, results });
  } catch (error) {
    console.error('New episodes error:', error.message);
    res.status(500).json({ success: false, error: 'Failed to fetch new episodes' });
  }
});

// Get anime movies
app.get('/api/movies', async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/movie`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    const $ = cheerio.load(response.data);
    
    const results = parseAnimeItems($, '.flw-item', 50);
    
    res.json({ success: true, results });
  } catch (error) {
    console.error('Movies error:', error.message);
    res.status(500).json({ success: false, error: 'Failed to fetch anime movies' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
